# Practical Sessions for North African Summer School in Machine Learning (NASSMA)

- Introduction to Machine Learning, Python and Tensorflow
- Computer Vision
- Recommender Systems
- Recurrent Neural Networks

This material is based on the practical sessions of the [Transylvanian Machine Learning Summer School](https://tmlss.ro).
